from testproject.urls.base import urlpatterns  # noqa
