def show_toolbar(request):
    return True
