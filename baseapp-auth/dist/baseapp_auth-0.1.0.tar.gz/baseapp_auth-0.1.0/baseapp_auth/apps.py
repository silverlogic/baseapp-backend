from django.apps import AppConfig


class AuthConfig(AppConfig):
    name = "baseapp_auth"

    def ready(self):
        pass
